package com.waldok.roomdbapp.db.entity;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ContactDAO {

    //insert data into database
    @Insert
    public long addContact(Contact contact);

    //Update the contents of data in database
    @Update
    public void updateContact(Contact contact);

    //Delete the contents of data in database
    @Delete
    public void deleteContact(Contact contact);

    @Query("select * from contacts")
    public List<Contact> getContacts();

    @Query("select * from contacts where contact_id ==:contactId")
    public Contact getContact(long contactId);

}
