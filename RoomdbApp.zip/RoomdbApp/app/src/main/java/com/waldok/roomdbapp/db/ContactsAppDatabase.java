package com.waldok.roomdbapp.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.waldok.roomdbapp.db.entity.Contact;
import com.waldok.roomdbapp.db.entity.ContactDAO;

@Database(entities = {Contact.class}, version = 1, exportSchema = false)
public abstract class ContactsAppDatabase extends RoomDatabase {

    public abstract ContactDAO getContactDAO();

    /*public static ContactDAO getContactDAO;

    //Linking the Dao with our Database
    //public abstract ContactDAO getContactDAO();
    public static ContactDAO getContactDAO() {
        return null;
    }*/
}
